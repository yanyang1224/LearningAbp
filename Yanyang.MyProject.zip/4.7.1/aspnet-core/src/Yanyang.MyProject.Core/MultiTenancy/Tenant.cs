﻿using Abp.MultiTenancy;
using Yanyang.MyProject.Authorization.Users;

namespace Yanyang.MyProject.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
